﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AoC
{
    class TestClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("AoC");
        }
    }
}
